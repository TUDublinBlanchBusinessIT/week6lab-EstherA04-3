<!-- Firstname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('firstname', 'Firstname:'); ?>

    <?php echo Form::text('firstname', null, ['class' => 'form-control']); ?>

</div>

<!-- Surname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('surname', 'Surname:'); ?>

    <?php echo Form::text('surname', null, ['class' => 'form-control']); ?>

</div>

<!-- Membertype Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('membertype', 'Membertype:'); ?>

    <?php echo Form::text('membertype', null, ['class' => 'form-control']); ?>

</div>

<!-- Dateofbirth Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('dateofbirth', 'Dateofbirth:'); ?>

    <?php echo Form::date('dateofbirth', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('members.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laravel\tennisClub\resources\views/members/fields.blade.php ENDPATH**/ ?>
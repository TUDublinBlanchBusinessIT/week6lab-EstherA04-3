<!-- Bookingdate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('bookingdate', 'Bookingdate:'); ?>

    <?php echo Form::date('bookingdate', null, ['class' => 'form-control']); ?>

</div>

<!-- Starttime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('starttime', 'Starttime:'); ?>

    <?php echo Form::text('starttime', null, ['class' => 'form-control']); ?>

</div>

<!-- Endtime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('endtime', 'Endtime:'); ?>

    <?php echo Form::text('endtime', null, ['class' => 'form-control']); ?>

</div>

<!-- Memberid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('memberid', 'Memberid:'); ?>

    <?php echo Form::number('memberid', null, ['class' => 'form-control']); ?>

</div>

<!-- Courtid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('courtid', 'Courtid:'); ?>

    <?php echo Form::number('courtid', null, ['class' => 'form-control']); ?>

</div>

<!-- Fee Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fee', 'Fee:'); ?>

    <?php echo Form::number('fee', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('bookings.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laravel\tennisClub\resources\views/bookings/fields.blade.php ENDPATH**/ ?>
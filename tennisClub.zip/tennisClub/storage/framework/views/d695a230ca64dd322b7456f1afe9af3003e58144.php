<table class="table table-responsive" id="courts-table">
    <thead>
        <th>Surface</th>
        <th>Floodlights</th>
        <th>Indoor</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $court->surface; ?></td>
            <td><?php echo $court->floodlights; ?></td>
            <td><?php echo $court->indoor; ?></td>
            <td>
                <?php echo Form::open(['route' => ['courts.destroy', $court->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('courts.show', [$court->id]); ?>" class='btn btn-default btn-xs'><i class="far fa-eye"></i></i></a>
                    <a href="<?php echo route('courts.edit', [$court->id]); ?>" class='btn btn-default btn-xs'><i class="far fa-edit"></i></i></a>
                    <?php echo Form::button('<i class="far fa-trash-alt"></i></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laravel\tennisClub\resources\views/courts/table.blade.php ENDPATH**/ ?>
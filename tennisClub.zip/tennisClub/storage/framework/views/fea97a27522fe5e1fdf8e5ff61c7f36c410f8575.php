<table class="table table-responsive" id="members-table">
    <thead>
        <th>Firstname</th>
        <th>Surname</th>
        <th>Membertype</th>
        <th>Dateofbirth</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $member->firstname; ?></td>
            <td><?php echo $member->surname; ?></td>
            <td><?php echo $member->membertype; ?></td>
            <td><?php echo $member->dateofbirth; ?></td>
            <td>
                <?php echo Form::open(['route' => ['members.destroy', $member->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('members.show', [$member->id]); ?>" class='btn btn-default btn-xs'><i class="far fa-eye"></i></i></a>
                    <a href="<?php echo route('members.edit', [$member->id]); ?>" class='btn btn-default btn-xs'><i class="far fa-edit"></i></i></a>
                    <?php echo Form::button('<i class="far fa-trash-alt"></i></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laravel\tennisClub\resources\views/members/table.blade.php ENDPATH**/ ?>
<!-- Bookingdate Field -->
<div class="form-group">
    {!! Form::label('bookingdate', 'Bookingdate:') !!}
    <p>{!! $booking->bookingdate !!}</p>
</div>

<!-- Starttime Field -->
<div class="form-group">
    {!! Form::label('starttime', 'Starttime:') !!}
    <p>{!! $booking->starttime !!}</p>
</div>

<!-- Endtime Field -->
<div class="form-group">
    {!! Form::label('endtime', 'Endtime:') !!}
    <p>{!! $booking->endtime !!}</p>
</div>

<!-- Memberid Field -->
<div class="form-group">
    {!! Form::label('memberid', 'Memberid:') !!}
    <p>{!! $booking->memberid !!}</p>
</div>

<!-- Courtid Field -->
<div class="form-group">
    {!! Form::label('courtid', 'Courtid:') !!}
    <p>{!! $booking->courtid !!}</p>
</div>

<!-- Fee Field -->
<div class="form-group">
    {!! Form::label('fee', 'Fee:') !!}
    <p>{!! $booking->fee !!}</p>
</div>

